package com.cardservice.entity;

public class Card {
	
	private String cardId;
	private String cardNumber;
	private String cardHolderName;
	private String accNo;
	private Boolean isDebitCard;
	private Boolean isActive;
	private Boolean isCreditCard;
	public Boolean getIsDebitCard() {
		return isDebitCard;
	}
	public void setIsDebitCard(Boolean isDebitCard) {
		this.isDebitCard = isDebitCard;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsCreditCard() {
		return isCreditCard;
	}
	public void setIsCreditCard(Boolean isCreditCard) {
		this.isCreditCard = isCreditCard;
	}
	public String getCardId() {
		return cardId;
	}
	public void setCardId(String cardId) {
		this.cardId = cardId;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	@Override
	public String toString() {
		return "Card [cardId=" + cardId + ", cardNumber=" + cardNumber + ", cardHolderName=" + cardHolderName
				+ ", accNo=" + accNo + ", isDebitCard=" + isDebitCard + ", isActive=" + isActive + ", isCreditCard="
				+ isCreditCard + "]";
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

}
