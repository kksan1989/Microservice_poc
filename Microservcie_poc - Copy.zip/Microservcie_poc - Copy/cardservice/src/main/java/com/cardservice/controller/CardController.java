package com.cardservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cardservice.dao.CardDao;
import com.cardservice.entity.Card;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class CardController {
	
	@Autowired
	private CardDao ed;
	
@RequestMapping("applynewcard")
public void applyCard() {
	ed.applyCard();
	
}

@RequestMapping("blockCard/{cardNo}")
public String blockCard(@PathVariable("cardNo")String cardNo) {
	String message=ed.blockCard(cardNo);
	return message;
}

@RequestMapping("carddetails/{cardNo}")
public Card getCardDetails(@PathVariable("cardNo")String cardNo) {
	Card card=ed.getCardDetails();
	return card;
}




}
