package com.cardservice.dao;

import org.springframework.stereotype.Repository;

import com.cardservice.entity.Card;

@Repository
public class CardDaoImpl implements CardDao {
	
	public  void applyCard() {
		
	}

	@Override
	public String blockCard(String cardNo) {
		String s="Card blocked sucessfully";
		return s;
		
	}

	@Override
	public Card getCardDetails() {
		Card card=new Card();
		return card;
	}

}
