package com.cardservice.dao;

import com.cardservice.entity.Card;

public interface CardDao {

	public  void applyCard() ;

	public String blockCard(String cardNo);

	public Card getCardDetails();

}
