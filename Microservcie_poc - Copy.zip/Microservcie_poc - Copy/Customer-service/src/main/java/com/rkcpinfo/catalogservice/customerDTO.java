package com.rkcpinfo.catalogservice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class customerDTO {
   
	private Long id;
    private String name;
    private double balance;
    private String savintype;
	public customerDTO(Long id, String name, double price, double balance,String savintype) {
		this.id=id;
		this.name=name;
		this.balance=balance;
		this.savintype=savintype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getSavintype() {
		return savintype;
	}
	public void setSavintype(String savintype) {
		this.savintype = savintype;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
