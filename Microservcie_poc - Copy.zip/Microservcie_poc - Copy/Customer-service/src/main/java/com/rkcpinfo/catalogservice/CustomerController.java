package com.rkcpinfo.catalogservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    SavingsServiceClient promotionServiceClient;

    /*@GetMapping("/customerdetail")
    public List<ProductDTO> products() {
        List<ProductDTO> productDTOs = new ArrayList<>();
        List<Customer> products = getProducts();
        for (Customer product : products) {
            String promotion = null;
            try {
                promotion = promotionServiceClient.getPromotionByProductId(product.getId());
            } catch (Exception e) {
                e.printStackTrace();
            }
            productDTOs.add(new ProductDTO(product.getId(),product.getName(), product.getBalance(),product.getBalance()));
        }
        return productDTOs;
    }*/

    private List<Customer> getCustomer() {
        List<Customer> products = new ArrayList<>();
        products.add(new Customer(100,"raja", 250000));
        products.add(new Customer(105,"navanitha", 35000));
        return products;
    }
}
