package com.Loanservice.Dao;

import java.util.List;

import com.Loanservice.Entity.Loan;

public interface LoanDAOInterface {


	List<Loan> getLoanDAO();

}
