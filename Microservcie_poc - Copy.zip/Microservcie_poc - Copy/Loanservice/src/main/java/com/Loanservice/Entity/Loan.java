package com.Loanservice.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Loantable")
public class Loan {
	
	@Id
	private int LoanNumber;

	private String LoanTYpe;
	
	public String getLoanTYpe() {
		return LoanTYpe;
	}

	public void setLoanTYpe(String loanTYpe) {
		LoanTYpe = loanTYpe;
	}

	

	
	public int getLoanNumber() {
		return LoanNumber;
	}

	public void setLoanNumber(int loanNumber) {
		LoanNumber = loanNumber;
	}
	
}