package com.Loanservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Loanservice.Dao.LoanDAOInterface;
import com.Loanservice.Entity.*;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class LoanController {
	
	@Autowired
	private LoanDAOInterface ed;
	
	@RequestMapping("/loanList")
	@HystrixCommand(fallbackMethod="getfallback")
	public List<Loan> getLoan() throws Exception{
		List<Loan> ll=ed.getLoanDAO();
		if(ll.size()>0)
		{
			throw new Exception();
		}
		/*Employee e1=new Employee();
		e1.setName("mahesh");
		e1.setPass("abcd");
		e1.setEmail("abc@yahoo.com");
		e1.setAddress("Bangalore");
		
		
		Employee e2=new Employee();
		e2.setName("mahesh1");
		e2.setPass("abcd1");
		e2.setEmail("abc@yahoo.com1");
		e2.setAddress("Bangalore1");
		
		ll.add(e1);
		ll.add(e2);*/
		return ll;
		
	}
	
	public List<Loan> getfallback(){
		List<Loan> ll=ed.getLoanDAO();
		Loan e1=new Loan();
		e1.setLoanNumber(1000);
		e1.setLoanTYpe("savings");
		
		
		ll.add(e1);
		
		return ll;
		
	}
}
