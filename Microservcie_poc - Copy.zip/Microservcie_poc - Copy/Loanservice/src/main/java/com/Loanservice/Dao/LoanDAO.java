package com.Loanservice.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Loanservice.Entity.Loan;


@Repository
public class LoanDAO implements LoanDAOInterface{
	
	@Autowired
	private EntityManagerFactory emf;

	
	@Override
	public List<Loan> getLoanDAO() {
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("from com.Loanservice.Entity.Loan ll");
		return q.getResultList();
	}

}












