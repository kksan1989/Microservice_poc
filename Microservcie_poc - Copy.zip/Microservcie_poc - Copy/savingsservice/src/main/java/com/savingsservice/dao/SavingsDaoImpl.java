package com.savingsservice.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.savingsservice.entity.Account;
import com.savingsservice.repository.AccountRepository;

@Repository
public class SavingsDaoImpl implements SavingsDao {
	
	@Autowired
	AccountRepository accountRepository;

	@Override
	public String createAccount(Account account) {
	
		Account acc=accountRepository.save(account);
		if(acc==null) {
			return "account creation failed";
		}
		return "account created sucessfully";
	}

	public String blockAccount(String accNo) {
		Account acc=accountRepository.findById(accNo).get();
		acc.setActive(false);
		Account ac1=accountRepository.save(acc);
		if(ac1 !=null) {
			return "Account blocked sucessfully";
		}
		else {
			return "Error while blocking account";
		}
		
	}
}
