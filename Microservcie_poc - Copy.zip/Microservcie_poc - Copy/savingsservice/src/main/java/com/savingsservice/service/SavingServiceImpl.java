package com.savingsservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.savingsservice.dao.SavingsDao;
import com.savingsservice.entity.Account;

@Service
public class SavingServiceImpl implements SavingService {

	@Autowired
	SavingsDao savingsDao;

	@Override
	public String createAccount(Account account) {
		String message=savingsDao.createAccount(account);
		return message;
	}
	
	@Override
	public String blockAccount(String accNo) {
		String message=savingsDao.blockAccount(accNo);
		return message;
	}
	
	
	
	
	
}
