package com.savingsservice.entity;

import java.util.Set;

import javax.persistence.OneToMany;

public class User {
	private String userId;
	private String userName;
	private String Address;
	private String userType;
	private boolean isActiveUser;
	@OneToMany(mappedBy="user")
	private Set<Account> accountList;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public boolean isActiveUser() {
		return isActiveUser;
	}
	public void setActiveUser(boolean isActiveUser) {
		this.isActiveUser = isActiveUser;
	}
	public Set<Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(Set<Account> accountList) {
		this.accountList = accountList;
	}


}
