package com.savingsservice.dao;

import com.savingsservice.entity.Account;

public interface SavingsDao {

	String createAccount(Account account);
	
	String blockAccount(String accNo);

}
