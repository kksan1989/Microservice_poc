package com.savingsservice.entity;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Account {
	
	private String accNo;
	private String accType;
	private boolean isActive;
	private long balanceAmt;
	@ManyToOne
    @JoinColumn(name="userId", nullable=false)
	private User user;
	
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public long getBalanceAmt() {
		return balanceAmt;
	}
	public void setBalanceAmt(long balanceAmt) {
		this.balanceAmt = balanceAmt;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	
}
