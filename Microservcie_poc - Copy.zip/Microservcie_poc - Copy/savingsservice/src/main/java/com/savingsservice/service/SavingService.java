package com.savingsservice.service;

import com.savingsservice.entity.Account;

public interface SavingService {

	String createAccount(Account account);

	String blockAccount(String accNo);

}
