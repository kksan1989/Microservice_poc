package com.savingsservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.savingsservice.entity.Account;
import com.savingsservice.service.SavingService;

@RestController
public class SavingsController {

	@Autowired
	SavingService savingService;
	
	@PostMapping("createaccount")
	public String createAccount(@RequestBody Account account) {
		String message=savingService.createAccount(account);
		return message;
	}
	
	@PutMapping("blockaccount")
	public String blockAccount(@RequestBody String accNo) {
		String message=savingService.blockAccount(accNo);
		return message;
	}
	
}
