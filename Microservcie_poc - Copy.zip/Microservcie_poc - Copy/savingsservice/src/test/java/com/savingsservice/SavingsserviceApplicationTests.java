package com.savingsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavingsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
