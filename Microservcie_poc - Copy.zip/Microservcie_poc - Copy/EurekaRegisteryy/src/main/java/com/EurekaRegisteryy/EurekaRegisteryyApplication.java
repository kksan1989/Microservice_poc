package com.EurekaRegisteryy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EurekaRegisteryyApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaRegisteryyApplication.class, args);
	}

}
